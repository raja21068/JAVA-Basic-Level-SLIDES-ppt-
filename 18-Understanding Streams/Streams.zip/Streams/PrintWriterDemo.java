import java.io.*;
class PrintWriterDemo {
	public static void main(String ar[]) throws Exception{
	PrintWriter pw = new PrintWriter(System.out, true);
	pw.print("abc");
	
	pw.close();
	}

}