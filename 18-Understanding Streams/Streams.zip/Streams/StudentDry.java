import java.io.*;
class StudentDry {

	public static void main(String ar[]) throws Exception{
	Student st = new Student(2222, "Hassam", "Java");
	FileOutputStream fos = new FileOutputStream("student.dat");
	
	ObjectOutputStream oos = new ObjectOutputStream(fos);

	oos.writeObject(st);

	fos.flush();
	oos.close();

	}
	
}