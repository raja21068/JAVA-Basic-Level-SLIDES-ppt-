class ReadByte{

public static void main(String ar[]) throws Exception{
	byte[] b = new byte[10];
	System.out.println("Enter 10 characters: ");
	System.in.read(b);
	for(byte bt : b){
	
		System.out.println((char)bt);
	}
}

}