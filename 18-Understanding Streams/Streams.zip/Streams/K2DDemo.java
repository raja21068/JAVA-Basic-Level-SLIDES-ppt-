import java.io.*;
class K2DDemo {
	public static void main(String ar[]) throws Exception{
	System.out.println("Enter Info (stop to quit)");
	InputStreamReader isr = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(isr);

	FileWriter fw = new FileWriter("data.txt" , true);
	String s;
	while( !(s = br.readLine()).equals("stop") ){
		s+="\r\n";
		fw.write(s);

	}
	fw.close();
	
	
	}

}