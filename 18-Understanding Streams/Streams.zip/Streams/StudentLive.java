import java.io.*;
class StudentLive {

	public static void main(String ar[]) throws Exception{
	
	FileInputStream fis = new FileInputStream("student.dat");
	
	ObjectInputStream ois = new ObjectInputStream(fis);
	Student s = (Student) ois.readObject();

	System.out.println(s);
	

	

	}
	
}