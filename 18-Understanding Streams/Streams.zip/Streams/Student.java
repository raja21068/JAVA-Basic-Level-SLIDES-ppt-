import java.io.*;
class Student implements  Serializable{
	int id;
	String name;
	String course;
	
	Student(int i , String n, String c){
		id = i;
		name = n;
		course = c;
	}

	public String toString(){
	return id+"\t"+name+"\t"+course;
	}

}