import java.io.*;
class D2SDemo {
	public static void main(String ar[]) throws Exception{
	
	FileReader fw = new FileReader("data.txt");
	BufferedReader br = new BufferedReader(fw);
	String s;
	while( (s = br.readLine()) != null){
		System.out.println(s);

	}
	fw.close();
	
	
	}

}