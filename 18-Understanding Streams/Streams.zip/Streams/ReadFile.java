import java.io.*;
import java.util.*;
class ReadFile{

public static void main(String ar[]) throws Exception{
	String fpath = "C:/Users/hidaya/Desktop/Streams/data.java";
	Scanner  sc = new Scanner(new FileInputStream(fpath));
	System.out.println(sc.nextLine());
	double sum=0;
	while(sc.hasNext()){
		String sub = sc.next();
		double marks = sc.nextDouble();
		sum+=marks;
		System.out.println(sub+"\t"+marks);
	
	}
	System.out.println("\t\t"+sum);
		
	
	


}

}