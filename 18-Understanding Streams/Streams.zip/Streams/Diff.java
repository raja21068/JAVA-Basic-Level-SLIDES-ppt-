import java.io.*;
class Diff {
	public static void main(String ar[]) throws Exception{
	FileInputStream f1 = new FileInputStream(ar[0]);
	FileInputStream f2 = new FileInputStream(ar[1]);
	
	int i,j;
	while( (i = f1.read()) != -1 && (j = f2.read()) != -1){
		if(i != j){
		System.out.println("Files differ");
		break;
		}
		
	}

	
	}

}