import java.io.*;
class ReadChars {
	public static void main(String ar[]) throws Exception{
	String i;
	InputStreamReader isr = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(isr);
	while( !(i = br.readLine()).equals("stop")){
	System.out.println(i);

	}
	
	}

}