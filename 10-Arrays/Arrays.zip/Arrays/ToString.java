class A{
String name;
	A(String n){
		name =n;
	}
	public String toString(){
	return "Name: "+name;
	}
	
}


public class ToString{
public static void main(String ar[])
{
A aob = new A("hidaya");
System.out.println(aob);


}

}